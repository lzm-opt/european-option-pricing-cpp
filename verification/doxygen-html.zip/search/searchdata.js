var indexSectionsWithContent =
{
  0: "abcdefgikmnoprstuv",
  1: "c",
  2: "o",
  3: "aempr",
  4: "bcmv",
  5: "dmrsv",
  6: "k",
  7: "cp",
  8: "abcdefgimnoprstu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Pages"
};

