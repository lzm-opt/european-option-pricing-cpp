var searchData=
[
  ['rate_0',['rate',['../structoption_1_1_contract.html#a3b89659db21b08c12a7d5434d34e4e51',1,'option::Contract']]],
  ['readme_2emd_1',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['repository_2',['Prepare the repository',['../md_docs_2publishing.html#autotoc_md18',1,'']]],
  ['resolution_3',['Timing at a fixed tree resolution',['../md_docs_2experiment-results.html#autotoc_md10',1,'']]],
  ['run_4',['run',['../index.html#autotoc_md1',1,'Build and run'],['../md_docs_2publishing.html#autotoc_md19',1,'Check the actual Actions run']]],
  ['runtime_20and_20approximation_20experiment_5',['Runtime and approximation experiment',['../md_docs_2experiment-results.html',1,'']]]
];
