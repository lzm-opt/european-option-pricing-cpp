var searchData=
[
  ['s_20account_0',['Publishing in the project owner&apos;s account',['../md_docs_2publishing.html',1,'']]],
  ['scholes_20evaluation_1',['Black-Scholes evaluation',['../md_docs_2algorithms.html#autotoc_md5',1,'']]],
  ['six_20item_20acceptance_20checklist_2',['Six-item acceptance checklist',['../md_docs_2acceptance.html',1,'']]],
  ['speed_20are_20different_20measurements_3',['Accuracy and speed are different measurements',['../md_docs_2algorithms.html#autotoc_md7',1,'']]],
  ['spot_4',['spot',['../structoption_1_1_contract.html#ac791b85b9febdbad47ccf89fb4141309',1,'option::Contract']]],
  ['strike_5',['strike',['../structoption_1_1_contract.html#aadea378498759be84ee02b121efb6b5d',1,'option::Contract']]],
  ['submit_6',['Submit',['../md_docs_2publishing.html#autotoc_md20',1,'']]],
  ['supported_20input_20domain_7',['Supported input domain',['../md_docs_2model.html#autotoc_md16',1,'']]]
];
