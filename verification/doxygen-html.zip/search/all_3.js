var searchData=
[
  ['different_20measurements_0',['Accuracy and speed are different measurements',['../md_docs_2algorithms.html#autotoc_md7',1,'']]],
  ['dividend_5fyield_1',['dividend_yield',['../structoption_1_1_contract.html#a684d8431c6888c0b0b9f94aaa18a54f6',1,'option::Contract']]],
  ['domain_2',['Supported input domain',['../md_docs_2model.html#autotoc_md16',1,'']]]
];
