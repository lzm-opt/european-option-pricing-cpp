var searchData=
[
  ['measurements_0',['Accuracy and speed are different measurements',['../md_docs_2algorithms.html#autotoc_md7',1,'']]],
  ['model_20and_20units_1',['Financial model and units',['../md_docs_2model.html',1,'']]]
];
