var searchData=
[
  ['s_20account_0',['Publishing in the project owner&apos;s account',['../md_docs_2publishing.html',1,'']]],
  ['scholes_20evaluation_1',['Black-Scholes evaluation',['../md_docs_2algorithms.html#autotoc_md5',1,'']]],
  ['six_20item_20acceptance_20checklist_2',['Six-item acceptance checklist',['../md_docs_2acceptance.html',1,'']]],
  ['speed_20are_20different_20measurements_3',['Accuracy and speed are different measurements',['../md_docs_2algorithms.html#autotoc_md7',1,'']]],
  ['submit_4',['Submit',['../md_docs_2publishing.html#autotoc_md20',1,'']]],
  ['supported_20input_20domain_5',['Supported input domain',['../md_docs_2model.html#autotoc_md16',1,'']]]
];
