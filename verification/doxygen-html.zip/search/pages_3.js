var searchData=
[
  ['different_20measurements_0',['Accuracy and speed are different measurements',['../md_docs_2algorithms.html#autotoc_md7',1,'']]],
  ['domain_1',['Supported input domain',['../md_docs_2model.html#autotoc_md16',1,'']]]
];
