var searchData=
[
  ['numerical_20checks_0',['Algorithms and numerical checks',['../md_docs_2algorithms.html',1,'']]]
];
