var searchData=
[
  ['grid_20approximation_20error_0',['Grid approximation error',['../md_docs_2experiment-results.html#autotoc_md11',1,'']]]
];
