var searchData=
[
  ['acceptance_2emd_0',['acceptance.md',['../acceptance_8md.html',1,'']]],
  ['algorithms_2emd_1',['algorithms.md',['../algorithms_8md.html',1,'']]]
];
